int func1(void) {
    return 23;
}
